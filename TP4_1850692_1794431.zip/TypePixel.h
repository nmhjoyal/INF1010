//
// Created by Gabriel Bernard
//

#ifndef TP3_TYPE_PIXEL_H
#define TP3_TYPE_PIXEL_H

enum TypePixel {
	NoireBlanc, NuanceDeGris, Couleur
};

#endif // TP3_TYPE_PIXEL_H